import 'dart:html';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:xylophonetest/contactus.dart';
import 'QuestionBank.dart';

QuestionBrain questionBrain = QuestionBrain();

void main() {
  runApp(MaterialApp(

    home: MyHomePage(),
  ));
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();

    Timer(
        Duration(seconds: 3),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => QuizApp())));

  }

  @override
  Widget build(BuildContext context) => Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 70.0,
            backgroundImage: AssetImage("images/as.jpg"),
          ),
          Text(
            'ASAD BASHIR',
            style: TextStyle(
                height: 2,
                fontFamily: 'SpecialElite',
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 40.0),
          ),
          Text(
            'Fa19-BCS-035',
            style: TextStyle(
                height: 3,
                fontFamily: 'SpecialElite',
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 30.0),
          ),
        ],

      );

}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      home: Scaffold(

        drawer: Drawer(
          backgroundColor: Color(0xFEDBF59C),
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the drawer if there isn't enough vertical
          // space to fit everything.
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.lime,

                ),
                child: CircleAvatar(
                  radius: 50.0,
                  backgroundImage: AssetImage("images/img_2.png"),
                ),
              ),
              Text(
                'Quiz App',
                style: TextStyle(
                    height: 2,
                    fontFamily: 'SpecialElite',
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0),
              ),
              Text(
                'Version 1.0.0',
                style: TextStyle(
                    height: 2,
                    fontFamily: 'SpecialElite',
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 15.0),
              ),
              ListTile(
                title: const Text('Home'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text('Feedback'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text('info'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text('Setting'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text('More app'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text('Contact Us'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>contact()));
                  // Update the state of the app

                  // Then close the drawer

                },
              ),
            ],
          ),
        ),
        backgroundColor: Color(0xFF0A0E47),
        appBar: AppBar(
          backgroundColor: Colors.orange,
          title: Text("QUIZ APP"),
          actions: <Widget>[],
        ),
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: QuizPage(),
          ),
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  List<Icon> scoreKeeper = [];

  int _counter = 10;
  Timer? _timer;



  void timestart() {
    _counter = 10;
    _timer = Timer.periodic(
      Duration(seconds: 1),
      (timer) {
        setState(() {
          if (_counter > 0) {
            _counter--;
          } else {
            if (questionBrain.isFinished() == false) {
              _counter = 10;
              _timer?.cancel();
              questionBrain.nextQuestion();
              scoreKeeper.add(Icon(
                Icons.close,
                color: Colors.lightGreen,
              ));
            }
          }
          ;
        });
      },
    );
  }

  void initState() {
    super.initState();
    timestart();
  }

  void checkAnswer(bool userAnswer) {
    bool? questionAnswer = questionBrain.getQuestionAnswer();
    setState(() {
      if (questionBrain.isFinished() == true) {
        Alert(
          context: context,
          type: AlertType.success,
          title: "Finished",
          desc: "You\'ve reached at the end of Quiz",
          buttons: [
            DialogButton(
              child: Text(
                "OK",
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () => Navigator.pop(context),
              width: 120,
            )
          ],
        ).show();
        questionBrain.reset();
        scoreKeeper = [];
      } else {
        if (questionAnswer == userAnswer) {
          scoreKeeper.add(
            Icon(
              Icons.check,
              color: Colors.green,
            ),
          );
        } else {
          scoreKeeper.add(
            Icon(
              Icons.close,
              color: Colors.red,
            ),
          );
        }
        questionBrain.nextQuestion();
      }
    });
  }

  @override

  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.stretch,

      children: [

        Expanded(
            child: Center(
          child: Text(
            "$_counter",
            style: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        )),
        Expanded(
          flex: 6,
          child: Padding(
            padding: EdgeInsets.all(10.0),
            child: Center(
              child: Text(
                questionBrain.getQuestionText().toString(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: FlatButton(
              onPressed: () {
                checkAnswer(true);
              },
              color: Colors.green[700],
              splashColor: Colors.green[700],
              highlightColor: Colors.green[900],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Text(
                'True',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: FlatButton(
              onPressed: () {
                checkAnswer(false);
              },
              color: Colors.red[600],
              splashColor: Colors.red[600],
              highlightColor: Colors.red[900],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Text(
                'False',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              ),
            ),
          ),
        ),
        Row(
          children: scoreKeeper,

        ),
      ],
    );
  }
}
