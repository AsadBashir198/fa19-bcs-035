

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:mb_contact_form/mb_contact_form.dart';

class contact extends StatefulWidget {
  const contact({Key? key}) : super(key: key);

  @override
  _contactState createState() => _contactState();
}

class _contactState extends State<contact> {
  @override
  Widget build(BuildContext context)

  {
    return MaterialApp(
      home: Scaffold(backgroundColor: Color(0xF5131945),
        body: SafeArea(child:
        Column(
          mainAxisAlignment:  MainAxisAlignment.center,
          children: [
            CircleAvatar(backgroundColor: Colors.amber,
              backgroundImage: AssetImage("images/as.jpg"),

              maxRadius: 70.0,
            ),
            Text(
              'Quiz App',
              style:TextStyle(
                  height: 2,
                  fontFamily: 'SpecialElite',
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 40.0),
            ),
            Text(
              'Contact Us',
              style:TextStyle(
                  fontFamily: 'SpecialElite-Regular',
                  color: Colors.white,
                  height: 2.0,
                  fontSize: 25.0),
            ),


            SizedBox(height: 50,
              width: 150,
              child: Divider(
                thickness: 1,
                height: 50,
                color: Colors.black,


              ),
            ),


            Card(
              margin: EdgeInsets.symmetric(vertical: 30,horizontal: 70),
              child: ListTile(
                  leading: Icon(Icons.call),
                  iconColor: Colors.purple,
                  textColor: Colors.black,
                  title:   Text("03099932032")
              ),

            ),

            Card(
              margin: EdgeInsets.symmetric(vertical:0,horizontal: 70),
              child:  ListTile(
                  leading: Icon(Icons.alternate_email_outlined),
                  iconColor: Colors.purple,
                  textColor: Colors.black,
                  title:   Text("asadbashir19832@gmail.com")
              ),

            ),

            Card(
              margin: EdgeInsets.symmetric(vertical:28,horizontal: 70),
              child: ListTile(
                  leading: Icon(Icons.home_filled),
                  iconColor: Colors.purple,
                  textColor: Colors.black,
                  title:   Text("Iqbal Town Lahore")
              ),

            ),


          ],
        )


        ),

      ),
    );
  }
}